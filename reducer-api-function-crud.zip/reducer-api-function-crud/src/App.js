import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import ReducerTokenApiCrud from './components/ReducerTokenApiFunctionCrud';

function App() {
  return (
    <div className="App">
      <ReducerTokenApiCrud />
    </div>
  );
}

export default App;
